SVN Digger v1.0 - 11/04/2011
====================
You can use these lists for finding hidden resources on the web applications.
More information : http://www.mavitunasecurity.com/blog/SVN-Digger-Better-Lists-for-Forced-Browsing/

They are licensed under GPL, feel free to share and use your own GPL-Compatible application.